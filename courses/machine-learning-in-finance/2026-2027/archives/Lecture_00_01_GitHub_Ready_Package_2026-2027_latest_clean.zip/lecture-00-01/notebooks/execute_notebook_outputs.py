import ast
import base64
import contextlib
import io
import json
from pathlib import Path

import matplotlib.pyplot as plt


NOTEBOOK = Path(__file__).with_name("lecture_00_01_colab.ipynb")


def plain_value(value):
    if hasattr(value, "to_string"):
        try:
            return value.to_string()
        except Exception:
            pass
    return repr(value)


def execute_cell(source, namespace):
    outputs = []
    stdout = io.StringIO()
    tree = ast.parse(source)
    last_value = None
    with contextlib.redirect_stdout(stdout):
        if tree.body and isinstance(tree.body[-1], ast.Expr):
            body = ast.Module(body=tree.body[:-1], type_ignores=[])
            exec(compile(body, "<colab-cell>", "exec"), namespace)
            last_value = eval(compile(ast.Expression(tree.body[-1].value), "<colab-cell>", "eval"), namespace)
        else:
            exec(compile(tree, "<colab-cell>", "exec"), namespace)
    if stdout.getvalue():
        outputs.append({"name": "stdout", "output_type": "stream", "text": stdout.getvalue().splitlines(True)})
    if last_value is not None:
        outputs.append({
            "name": "stdout",
            "output_type": "execute_result",
            "execution_count": None,
            "data": {"text/plain": plain_value(last_value).splitlines(True)},
            "metadata": {},
        })
    for number in plt.get_fignums():
        figure = plt.figure(number)
        payload = io.BytesIO()
        figure.savefig(payload, format="png", dpi=120, bbox_inches="tight")
        outputs.append({
            "output_type": "display_data",
            "data": {"image/png": base64.b64encode(payload.getvalue()).decode("ascii")},
            "metadata": {},
        })
    plt.close("all")
    return outputs


notebook = json.loads(NOTEBOOK.read_text())
namespace = {"__name__": "__main__"}
for cell in notebook["cells"]:
    if cell.get("cell_type") != "code":
        continue
    source = "".join(cell.get("source", []))
    try:
        cell["outputs"] = execute_cell(source, namespace)
        cell["execution_count"] = (cell.get("execution_count") or 0) + 1
    except Exception as error:
        cell["outputs"] = [{
            "output_type": "error",
            "ename": type(error).__name__,
            "evalue": str(error),
            "traceback": [],
        }]
        raise

NOTEBOOK.write_text(json.dumps(notebook, indent=1))
print(f"Executed {sum(c.get('cell_type') == 'code' for c in notebook['cells'])} code cells")
